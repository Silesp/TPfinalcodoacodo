CREATE TABLE producto(
    id_repuesto INT(10)     NOT NULL AUTO_INCREMENT,
    nombre      VARCHAR(40) NOT NULL,
    precio      INT(10)     NOT NULL,
    codigo      VARCHAR(10) NOT NULL,
    PRIMARY KEY (id_repuesto)
)