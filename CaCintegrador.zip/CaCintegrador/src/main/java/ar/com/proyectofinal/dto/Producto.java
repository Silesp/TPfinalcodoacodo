package ar.com.proyectofinal.dto;

public class Producto {
	private int id_repuesto;
	private String nombre;
	private int precio;
	private String codigo;

	public Producto(int id_repuesto, String nombre, int precio, String codigo) {
		super();
		this.id_repuesto = id_repuesto;
		this.nombre = nombre;
		this.precio = precio;
		this.codigo = codigo;
	}

	public int getId_repuesto() {
		return id_repuesto;
	}

	public void setId_repuesto(int id_repuesto) {
		this.id_repuesto = id_repuesto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
}