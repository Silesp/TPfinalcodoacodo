package ar.com.proyectofinal.daos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ar.com.proyectofinal.Connection.AdministradorDeConexiones;
import ar.com.proyectofinal.dto.Producto;

public class ProductosDAO {

	public ProductosDAO(int id_repuesto, String nombre, int precio, String codigo) {
	}


	public ProductosDAO obtenerPorId(int id) {
		String sql = "SELECT * FROM Producto WHERE ID_REPUESTO=" + id;


		Connection con = AdministradorDeConexiones.getConnection();

		ProductosDAO productFromDb = null;

		try {
			Statement st = con.createStatement();


			ResultSet rs = st.executeQuery(sql);



			if (rs.next()) {

				int id_repuesto = rs.getInt(1);
				String nombre = rs.getString(2);
				int precio = rs.getInt(3);
				String codigo = rs.getString(4);

				//campos crear un objeto????
				productFromDb = new ProductosDAO(id_repuesto, nombre, precio, codigo);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return productFromDb;
	}

	public List<Producto> listarProducto() {
		String sql = "SELECT * FROM Producto ";

		//Connection
		Connection con = AdministradorDeConexiones.getConnection();

		List<Producto> list = new ArrayList<>();

		//Statement
		try {
			Statement st = con.createStatement();

			//resultset
			ResultSet rs = st.executeQuery(sql);



			while (rs.next()) {//

				int id_repuesto = rs.getInt(1);
				String nombre = rs.getString(2);
				int precio = rs.getInt(3);
				String codigo = rs.getString(4);


				Producto productFromDb = new Producto(id_repuesto, nombre, precio, codigo);


				list.add(productFromDb);
			}


			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return list;
	}


	public void crearProducto(String nombre, int precio, String codigo) {

		Connection con = AdministradorDeConexiones.getConnection();

		if (con != null) {
			// insert en la db > SQL: INSERT INTO....
			String sql = "INSERT INTO Producto (id_repuesto, nombre, precio,codigo) ";
			sql += "VALUES('" + nombre + "'," + precio + ",'" + codigo + "')";


			try {
				Statement st = con.createStatement();
				st.execute(sql);

				con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}